==============================================
  GOLDPHARMA FULL LEAK — NEMO // NOV 2024
==============================================

Ce dossier contient une sélection des fichiers extraits
des serveurs internes de Goldpharma Group lors de
l'Operation PharmaVeil menée par le groupe NEMO.

CONTENU DE CE DOSSIER (partiel) :
- OFFSHORE_ACCOUNTS_CONFIDENTIAL.csv
- INTERNAL_MEMO_DO_NOT_DISTRIBUTE.txt
- nexaplex_patients_DUMP_partial.sql
- DOCTORS_PAYMENT_LIST_2009-2023.csv
- REAL_ESTATE_ASSETS_CLASSIFIED.txt

DUMP COMPLET (4.7 GB) : distribué à 47 rédactions.

Nous sommes partout.
Nous sommes personne.
Nous sommes NEMO.

goldpharma.com — OFFLINE
==============================================
