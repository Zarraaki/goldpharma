-- GOLDPHARMA DATABASE DUMP — PARTIAL EXTRACT
-- Extracted by: NEMO // 2024-11-07 03:14:22 UTC
-- WARNING: 4.7GB full dump available on request

CREATE TABLE patients_nexaplex (
  id INT PRIMARY KEY,
  first_name VARCHAR(50),
  last_name VARCHAR(50),
  dob DATE,
  country VARCHAR(30),
  prescription_date DATE,
  dosage_mg INT,
  dependency_flag BOOLEAN,
  deceased BOOLEAN,
  death_date DATE
);

-- Sample rows (full: 2.847.392 records)
INSERT INTO patients_nexaplex VALUES (1,'[REDACTED]','[REDACTED]','1958-04-12','France','2009-03-01',40,TRUE,TRUE,'2019-07-23');
INSERT INTO patients_nexaplex VALUES (2,'[REDACTED]','[REDACTED]','1963-11-30','Germany','2010-06-15',60,TRUE,TRUE,'2021-02-14');
INSERT INTO patients_nexaplex VALUES (3,'[REDACTED]','[REDACTED]','1971-08-07','Spain','2011-01-22',40,TRUE,FALSE,NULL);
-- ... 2.847.389 more rows truncated
-- DECEASED FLAG = TRUE : 10.247.891 records across full dataset

SELECT COUNT(*) FROM patients_nexaplex WHERE deceased = TRUE;
-- Result: 10247891
